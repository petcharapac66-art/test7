#ifndef SMARTMED7_TIME_SCHEDULING_H
#define SMARTMED7_TIME_SCHEDULING_H

#include <Arduino.h>
#include <RTClib.h>

// Header-only module: include this file ONCE in SmartMed7.ino, after the
// shared globals have been declared. Do not also compile an old
// TimeScheduling.ino containing the same function definitions.
//
// Required existing globals:
// RTC_DS3231 rtc;
// int breakfastHour, breakfastMinute, lunchHour, lunchMinute, dinnerHour, dinnerMinute;
// bool breakfastAlarm, lunchAlarm, dinnerAlarm;
// uint32_t lastBreakfastDate, lastLunchDate, lastDinnerDate;
// int currentMeal;
// bool medicationWaiting;
// DateTime medicationStartTime;
// enum RiskLevel { RISK_LOW, RISK_MEDIUM, RISK_HIGH };
// RiskLevel currentRisk;
// int reminderRepeatCount;
// unsigned long lastReminderMillis;
// const unsigned long REMINDER_INTERVAL, MEDICATION_TIMEOUT;
//
// Existing functions implemented by other tabs:
void sendBLE(String message);
void startLEDBlink();
void setLEDBlinkByRisk();
void setLEDOff();
void stopAlarm();
void playFile(int fileNumber);

inline uint32_t getDateKey(DateTime now) {
  return (uint32_t)now.year() * 10000UL + (uint32_t)now.month() * 100UL + (uint32_t)now.day();
}

void setCurrentMedication(int mealIndex) {

  DateTime now = rtc.now();

  int hour = -1;
  int minute = -1;

  switch (mealIndex) {

    case 1:
      // currentMeal stays 0 for breakfast (BLE / Sound).
      hour = breakfastHour;
      minute = breakfastMinute;
      break;

    case 2:
      // currentMeal stays 1 for lunch (BLE / Sound).
      hour = lunchHour;
      minute = lunchMinute;
      break;

    case 3:
      // currentMeal stays 2 for dinner (BLE / Sound).
      hour = dinnerHour;
      minute = dinnerMinute;
      break;

    default:
      Serial.println("ERROR: Invalid meal");
      scheduledDoseTimeValid = false;
      return;
  }

  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
    Serial.println("ERROR: Meal time not configured");
    scheduledDoseTimeValid = false;
    return;
  }

  scheduledDoseTime = DateTime(
    now.year(),
    now.month(),
    now.day(),
    hour,
    minute,
    0);

  scheduledDoseTimeValid = true;

  Serial.println("===== CURRENT MEDICATION =====");
  Serial.println(String("Meal: ") + String(currentMeal));

  Serial.print("Scheduled time: ");
  Serial.print(hour);
  Serial.print(":");
  Serial.println(minute);
}

inline String mealName(int meal) {
  if (meal == 0) return "เช้า";
  if (meal == 1) return "กลางวัน";
  if (meal == 2) return "เย็น";
  return "-";
}

inline String getMealBLEKey(int meal) {
  if (meal == 0) return "MORNING";
  if (meal == 1) return "NOON";
  if (meal == 2) return "EVENING";
  return "UNKNOWN";
}

inline bool parseTime(String text, int& hour, int& minute) {
  text.trim();
  if (text.length() != 5 || text.charAt(2) != ':') return false;
  if (!isDigit(text.charAt(0)) || !isDigit(text.charAt(1)) || !isDigit(text.charAt(3)) || !isDigit(text.charAt(4))) return false;
  int h = text.substring(0, 2).toInt();
  int m = text.substring(3, 5).toInt();
  if (h > 23 || m > 59) return false;
  hour = h;
  minute = m;
  return true;
}

// inline void printSchedule() {
//   Serial.println("========= MEDICATION TIME =========");
//   if (breakfastHour >= 0) Serial.printf("Breakfast: %02d:%02d\n", breakfastHour, breakfastMinute);
//   else Serial.println("Breakfast: not set");
//   if (lunchHour >= 0) Serial.printf("Lunch: %02d:%02d\n", lunchHour, lunchMinute);
//   else Serial.println("Lunch: not set");
//   if (dinnerHour >= 0) Serial.printf("Dinner: %02d:%02d\n", dinnerHour, dinnerMinute);
//   else Serial.println("Dinner: not set");
// }

inline String formatMedicationTime(int hour, int minute) {
  if (hour < 0 || minute < 0) {
    return "Not set";
  }

  char buffer[6];
  snprintf(buffer, sizeof(buffer), "%02d:%02d", hour, minute);

  return String(buffer);
}

inline void printSchedule() {
  Serial.println("========= MEDICATION TIME =========");

  Serial.println("Breakfast: " + formatMedicationTime(breakfastHour, breakfastMinute));

  Serial.println("Lunch: " + formatMedicationTime(lunchHour, lunchMinute));

  Serial.println("Dinner: " + formatMedicationTime(dinnerHour, dinnerMinute));

  // Dose timestamp is set only when a specific meal alarm starts.
}

// inline bool sendScheduleToGoogleSheets() {

//   String breakfastTime =
//     formatMedicationTime(breakfastHour, breakfastMinute);

//   String lunchTime =
//     formatMedicationTime(lunchHour, lunchMinute);

//   String dinnerTime =
//     formatMedicationTime(dinnerHour, dinnerMinute);

//   String dateSchedule =
//     breakfastTime + ", " +
//     lunchTime + ", " +
//     dinnerTime;

//   Serial.println("Uploading medication schedule...");
//   Serial.println(dateSchedule);

// bool result = sendWebTest(
//   "Set Time",    // Date and time from DS3231
//   "Breakfast, Lunch, Dinner",             // Command
//   dateSchedule,           // Data sent
//   "TIME_SAVED",           // Expected response; see note below
//   "Successful",           // Status
//   "Schedule Saved"        // Condition
// );

// Serial.println(
//   result ? "UPLOAD SUCCESS" : "UPLOAD FAILED"
// );

//   return result;
// }

inline void clearMedicationSchedule() {
  breakfastHour = breakfastMinute = -1;
  lunchHour = lunchMinute = -1;
  dinnerHour = dinnerMinute = -1;
  breakfastAlarm = lunchAlarm = dinnerAlarm = false;
  lastBreakfastDate = lastLunchDate = lastDinnerDate = 0;
  // Do not cancel an already-active dose: its completion or timeout
  // must still be recorded.
  sendBLE("TIME_CLEARED");
}

inline void parseSchedule(String command) {
  if (!command.startsWith("SET_TIME:")) {
    sendBLE("TIME_ERROR");
    return;
  }
  String data = command.substring(9);
  int comma1 = data.indexOf(',');
  int comma2 = data.indexOf(',', comma1 + 1);
  if (comma1 < 0 || comma2 < 0 || data.indexOf(',', comma2 + 1) >= 0) {
    sendBLE("TIME_ERROR");
    return;
  }
  int bh, bm, lh, lm, dh, dm;
  if (!parseTime(data.substring(0, comma1), bh, bm) || !parseTime(data.substring(comma1 + 1, comma2), lh, lm) || !parseTime(data.substring(comma2 + 1), dh, dm)) {
    sendBLE("TIME_ERROR");
    return;
  }
  breakfastHour = bh;
  breakfastMinute = bm;
  lunchHour = lh;
  lunchMinute = lm;
  dinnerHour = dh;
  dinnerMinute = dm;
  breakfastAlarm = lunchAlarm = dinnerAlarm = false;
  // Mark schedules already passed today so editing does not trigger
  // an unexpected alarm in the same minute.
  DateTime now = rtc.now();
  uint32_t today = getDateKey(now);
  int nowMin = now.hour() * 60 + now.minute();
  lastBreakfastDate = (bh * 60 + bm <= nowMin) ? today : 0;
  lastLunchDate = (lh * 60 + lm <= nowMin) ? today : 0;
  lastDinnerDate = (dh * 60 + dm <= nowMin) ? today : 0;
  printSchedule();
  // bool result2 = sendScheduleToGoogleSheets();
  // NEW: Request Google Sheets upload
  sendBLE("TIME_SAVED");
}

inline void setRiskLevel(String risk) {
  risk.trim();
  risk.toUpperCase();
  if (risk == "LOW") currentRisk = RISK_LOW;
  else if (risk == "MEDIUM") currentRisk = RISK_MEDIUM;
  else if (risk == "HIGH") currentRisk = RISK_HIGH;
  else {
    sendBLE("RISK_ERROR");
    return;
  }
  Serial.println("Risk level: " + risk);
}

// Audio playback is delegated to Sound.h. This function starts one pair
// without a blocking 10-second delay; the second file can be scheduled by
// Sound.h using its existing updateSound() mechanism.
inline void playRiskReminderOnce() {
  if (!medicationWaiting || currentMeal < 0) return;
  // playMealSound() starts the 1st file, updateSound() handles the 2nd.
  extern void playMealSound(int meal);
  playMealSound(currentMeal);
}

inline void playImmediateReminder(int times) {
  // First pair of meal audio files plays immediately; repeats are scheduled.
  // This intentionally avoids restarting DFPlayer 3 times in a tight loop.
  (void)times;
  playRiskReminderOnce();
  lastReminderMillis = millis();
}

inline void startMealAlarm(int meal) {
  if (medicationWaiting) {
    Serial.println("Another medication event is still active; alarm not replaced");
    return;
  }
  currentMeal = meal;
  medicationWaiting = true;
  medicationStartTime = rtc.now();
  reminderRepeatCount = 0;
  lastReminderMillis = millis();
  setLEDBlinkByRisk();
  playImmediateReminder(currentRisk == RISK_LOW ? 1 : 3);
  if (meal == 0) {
    sendBLE("ALARM|BREAKFAST");
    setCurrentMedication(1);
  } else if (meal == 1) {
    sendBLE("ALARM|LUNCH");
    setCurrentMedication(2);
  } else if (meal == 2) {
    sendBLE("ALARM|DINNER");
    setCurrentMedication(3);
  }
  Serial.println("Alarm started: " + mealName(meal));
}

inline void checkMedicationTime(DateTime now) {
  if (medicationWaiting) return;
  uint32_t today = getDateKey(now);
  int meal = -1;
  if (breakfastHour >= 0 && now.hour() == breakfastHour && now.minute() == breakfastMinute && lastBreakfastDate != today) {
    meal = 0;
    lastBreakfastDate = today;
    breakfastAlarm = true;
    // String timeSetting = String(now.hour()) + ":" + String(now.minute());
    // bool result1 = sendWebTest(
    //   "Set time",
    //   "Morning",
    //   timeSetting,
    //   timeSetting,
    //   "Successful",
    //   "----"
    // );

    // Serial.println(
    //   result1 ? "UPLOAD SUCCESS" : "UPLOAD FAILED"
    // );
  } else if (lunchHour >= 0 && now.hour() == lunchHour && now.minute() == lunchMinute && lastLunchDate != today) {
    meal = 1;
    lastLunchDate = today;
    lunchAlarm = true;

    // String timeSetting = String(now.hour()) + ":" + String(now.minute());
    // bool result1 = sendWebTest(
    //   "Set time",
    //   "Afternoon",
    //   timeSetting,
    //   timeSetting,
    //   "Successful",
    //   "----"
    // );

    // Serial.println(
    //   result1 ? "UPLOAD SUCCESS" : "UPLOAD FAILED"
    // );
  } else if (dinnerHour >= 0 && now.hour() == dinnerHour && now.minute() == dinnerMinute && lastDinnerDate != today) {
    meal = 2;
    lastDinnerDate = today;
    dinnerAlarm = true;

    // String timeSetting = String(now.hour()) + ":" + String(now.minute());
    // bool result1 = sendWebTest(
    //   "Set time",
    //   "Evening",
    //   timeSetting,
    //   timeSetting,
    //   "Successful",
    //   "----"
    // );

    // Serial.println(
    //   result1 ? "UPLOAD SUCCESS" : "UPLOAD FAILED"
    // );
  }
  if (meal >= 0) startMealAlarm(meal);
}

inline void markMedicationMissed() {
  if (!medicationWaiting) return;
  String key = getMealBLEKey(currentMeal);
  stopAlarm();
  setLEDOff();
  medicationWaiting = false;
  currentMeal = -1;
  sendBLE("MISSED|" + key);
  Serial.println("Medication missed: " + key);
}

inline void updateRiskReminder() {
  if (!medicationWaiting) return;
  long elapsed = (rtc.now() - medicationStartTime).totalseconds();
  // 30 minute
  if (elapsed >= 1800) {
    markMedicationMissed();
    Serial.println("RISK: High");

    return;
  }

  if (currentRisk == RISK_LOW) {
    Serial.println("RISK: Low");
    return;
  }

  if (millis() - lastReminderMillis < REMINDER_INTERVAL) return;
  lastReminderMillis = millis();

  if (currentRisk == RISK_MEDIUM && reminderRepeatCount >= 2) return; // 3 rounds total including first
  ++reminderRepeatCount;
  Serial.println("RISK reminder repeat");

  playRiskReminderOnce();
}

inline void handleTaken() {
  if (!medicationWaiting) {
    sendBLE("NO_MEDICATION");
    return;
  }
  int meal = currentMeal;
  long elapsed = (rtc.now() - medicationStartTime).totalseconds();
  String status = (elapsed <= 300) ? "TAKEN_ON_TIME|" : (elapsed <= 1800) ? "TAKEN_LATE|"
                                                                          : "MISSED|";
  medicationWaiting = false;
  currentMeal = -1;
  stopAlarm();
  setLEDOff();
  sendBLE(status + getMealBLEKey(meal));
}

#endif  // SMARTMED7_TIME_SCHEDULING_H
