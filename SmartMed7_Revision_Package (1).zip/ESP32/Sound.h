#ifndef SMARTMED7_SOUND_H
#define SMARTMED7_SOUND_H
#include <Arduino.h>
#include <HardwareSerial.h>
#include <DFRobotDFPlayerMini.h>
extern HardwareSerial dfSerial;
extern DFRobotDFPlayerMini dfPlayer;
extern bool dfReady;
extern int soundMeal;
extern int soundStep;
extern unsigned long soundStartMillis;
inline void initSound() {
  dfSerial.begin(9600, SERIAL_8N1, 16, 17);
  dfReady = dfPlayer.begin(dfSerial);
  if (dfReady) dfPlayer.volume(30);
  Serial.println(dfReady ? "DFPlayer ready" : "DFPlayer not detected");
}
inline void playFile(int fileNumber) {
  if (!dfReady || fileNumber < 1 || fileNumber > 2999) return;
  dfPlayer.stop(); delay(150);
  dfPlayer.playMp3Folder(fileNumber);
}
inline void playMealSound(int meal) {
  if (!dfReady || meal < 0 || meal > 2) return;
  soundMeal = meal;
  soundStep = 1;
  soundStartMillis = millis();
  playFile(meal * 2 + 1);
}
inline void updateSound() {
  if (soundMeal < 0 || millis() - soundStartMillis < 5000UL) return;
  if (soundStep == 1) {
    playFile(soundMeal * 2 + 2);
    soundStep = 2;
    soundStartMillis = millis();
  } else if (soundStep == 2) {
    soundMeal = -1;
    soundStep = 0;
  }
}
inline void stopAlarm() {
  if (dfReady) dfPlayer.stop();
  soundMeal = -1;
  soundStep = 0;
}
#endif
